"""Explainability for the settings layer (issue #120), read-only.

Read-only: this module never writes anything. It answers "why does it look
like this" questions against the live config state (the target shell.json,
with registry defaults for unset keys — the same effective-value semantics
ConfigObject's fallback gives the QML side), in the exact style the issue
itself shows:

    "Blur is enabled because Glass Mode is currently active."
    "The launcher scale is currently set to 1.25x."

Grounding is the same registry + citations as every other tool: causal
answers come from registry.EXPLAIN_RULES (each rule carries its own
file:line citations); with no rule firing, the
answer is the live value readback with validation, default and the C++
declaration citation.

Honesty note (offline vs in-shell): the QML service evaluates the same
rules with LIVE session flags (GameMode.enabled, Colours.light). This CLI
only sees the file, so rules referencing _gamemode/_light do not fire
here — they fall through to the value readback instead of guessing.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from .parser import _NOUN_RES, _noun_matched, _normalize
from .registry import EXPLAIN_RULES, TOOL_SPECS, ToolSpec, tool_by_name, tool_by_path

FileTarget = Union[str, Path]

# Read-only adjective forms the \b-bounded write-path nouns intentionally
# do not match (the write path stays byte-frozen; only the read
# path learns these). Keep this list small and obvious.
EXPLAIN_SYNONYMS: Dict[str, str] = {
    "blurry": "blur",
    "fuzzy": "blur",
    "laggy": "animations",
    "sluggish": "animations",
    "hide": "auto hide",
    "hides": "auto hide",
    "hidden": "auto hide",
    "disappear": "auto hide",
    "disappears": "auto hide",
}

# Phenomenon adjectives that should pick a specific candidate when that
# candidate is already noun-matched ("why is my bar big" -> the SIZE tool,
# not the position tool). Read-only; the write path is unchanged.
EXPLAIN_PREFERENCES: Dict[str, str] = {
    "big": "setBarScale",
    "large": "setBarScale",
    "huge": "setBarScale",
    "small": "setBarScale",
    "tiny": "setBarScale",
    "giant": "setDockIconSize",
    "slow": "setAnimationSpeed",
    "fast": "setAnimationSpeed",
    "speedy": "setAnimationSpeed",
    "snappy": "setAnimationSpeed",
}


class ExplainError(RuntimeError):
    """Raised when a question cannot be answered."""


def _read_state(target: FileTarget, specs: List[ToolSpec]) -> Dict[str, Any]:
    """Effective state for the given specs: file value, else default."""
    import json

    path = Path(target)
    data: Dict[str, Any] = {}
    if path.exists():
        try:
            parsed = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(parsed, dict):
                data = parsed
        except (OSError, ValueError):
            raise ExplainError(
                f"target file {path} cannot be parsed; nothing was written"
            )
    state: Dict[str, Any] = {}
    for spec in specs:
        node: Any = data
        for segment in spec.path.split("."):
            if not isinstance(node, dict) or segment not in node:
                node = None
                break
            node = node[segment]
        state[spec.path] = spec.default if node is None else node
    return state


def _paths_in(expr: str) -> List[str]:
    """Dotted paths referenced by a rule's `when` predicate."""
    out: List[str] = []
    for token in re.findall(r"[A-Za-z_][\w.]*", expr):
        if token not in ("true", "false") and token not in out:
            out.append(token)
    return out


def _values_equal(have: Any, want: Any) -> bool:
    if have == want:
        return True
    if isinstance(have, (int, float)) and isinstance(want, (int, float)) \
            and not isinstance(have, bool) and not isinstance(want, bool):
        return abs(float(have) - float(want)) < 1e-9
    if isinstance(have, bool) and isinstance(want, str):
        return str(have).lower() == want.lower()
    return False


def _eval_when(rule: Dict[str, Any], state: Dict[str, Any]) -> bool:
    """The restricted predicate grammar (same spec as the QML service):
    `path == value` / `!=` / `>` / `<` joined by ` and `. Unknown state
    keys (live-session flags the file cannot know) make the rule NOT fire."""
    clauses = str(rule["when"]).split(" and ")
    for clause in clauses:
        m = re.match(r"^\s*([\w.]+)\s*(==|!=|>|<)\s*(.+?)\s*$", clause)
        if not m:
            return False
        key, op, raw = m.group(1), m.group(2), m.group(3)
        have = state.get(key)
        if have is None:
            return False
        if raw == "true":
            want: Any = True
        elif raw == "false":
            want = False
        elif re.fullmatch(r"-?\d+(\.\d+)?", raw):
            want = float(raw) if "." in raw else int(raw)
        else:
            want = raw.strip("\"'")
        if op == "==":
            ok = _values_equal(have, want)
        elif op == "!=":
            ok = not _values_equal(have, want)
        elif op == ">":
            ok = isinstance(have, (int, float)) and have > want
        else:
            ok = isinstance(have, (int, float)) and have < want
        if not ok:
            return False
    return True


def _fmt(value: Any) -> str:
    if value is True:
        return "on"
    if value is False:
        return "off"
    if isinstance(value, float):
        return f"{round(value, 2):g}"
    return str(value)


def _render(template: str, state: Dict[str, Any], cites: Tuple[str, ...]) -> str:
    """Render an answer template. Placeholders:
    {dotted.path} -> formatted value; {cite}/{citeN} -> citations;
    {a|b} -> alternation resolved by the first numeric value placeholder
    in the template (> 1 picks the first option). Same spec as QML."""
    out = template
    first_numeric: Optional[float] = None
    m = re.search(r"\{([A-Za-z_][\w.]*)\}", out)
    if m:
        v = state.get(m.group(1))
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            first_numeric = float(v)
    out = re.sub(
        r"\{([^{}|]+)\|([^{}]+)\}",
        lambda mm: mm.group(1) if (first_numeric is not None and first_numeric > 1)
        else mm.group(2),
        out,
    )
    out = re.sub(
        r"\{cite(\d*)\}",
        lambda mm: cites[int(mm.group(1)) - 1] if mm.group(1)
        else (cites[0] if cites else ""),
        out,
    )
    out = re.sub(
        r"\{([A-Za-z_][\w.]*)\}",
        lambda mm: _fmt(state[mm.group(1)]) if mm.group(1) in state else mm.group(0),
        out,
    )
    return out


def resolve_spec(query: str) -> Optional[ToolSpec]:
    """A path, a tool name, or a noun-matched question -> one ToolSpec.

    Noun matching reuses the parser's own matcher (so the write and read
    surfaces share one noun grammar), with two READ-ONLY refinements the
    frozen write path deliberately does not get:

    - EXPLAIN_SYNONYMS: adjective forms ("blurry" -> "blur") that the
      \\b-bounded write-path nouns intentionally do not match;
    - phenomenon preference: for "why is my X so Y" questions, candidates
      whose noun matches in the predicate tail (after is/looks/seems/so)
      win over candidates that only matched the subject ("dock" is
      incidental in "why is my dock blurry" — the phenomenon is blur).

    Ambiguity that survives both refinements does not guess: None."""
    q = query.strip()
    spec = tool_by_path(q) or tool_by_name(q)
    if spec is not None:
        return spec
    text = _normalize(q)
    for adj, noun in EXPLAIN_SYNONYMS.items():
        if re.search(rf"\b{re.escape(adj)}\b", text):
            text = text.replace(adj, noun)
    matched = _noun_matched(text)
    if len(matched) > 1:
        # Preference adjectives first: an explicit phenomenon word picks
        # its tool when that tool is among the candidates.
        for word, tool_name in EXPLAIN_PREFERENCES.items():
            if re.search(rf"\b{re.escape(word)}\b", text):
                preferred = next((s for s in matched if s.name == tool_name), None)
                if preferred is not None:
                    return preferred
        # Phenomenon preference: in "why is my X so Y", Y (the predicate)
        # comes LAST — the candidate whose noun matches latest in the
        # sentence is the phenomenon being asked about; the subject ("dock"
        # in "why is my dock blurry") is incidental. Deterministic and
        # position-based; ties stay ambiguous (no guessing).
        def last_position(spec: ToolSpec) -> int:
            best = -1
            for regex in _NOUN_RES[spec.name]:
                for m in regex.finditer(text):
                    best = max(best, m.end())
            return best

        positions = {spec.name: last_position(spec) for spec in matched}
        latest = max(positions.values())
        winners = [s for s in matched if positions[s.name] == latest]
        if len(winners) == 1:
            return winners[0]
        matched = winners
    if len(matched) == 1:
        return matched[0]
    return None


def explain(query: str, target: FileTarget) -> Dict[str, Any]:
    """Answer one explainability question against the target file.

    Returns {ok, answer, cites, rule, spec}. Never writes.
    """
    spec = resolve_spec(query)
    if spec is None:
        candidates = _noun_matched(_normalize(query))
        if candidates:
            names = ", ".join(s.name for s in candidates)
            raise ExplainError(
                f"the question's noun matches are ambiguous ({names}); "
                "name the setting explicitly (a path or a tool name)"
            )
        raise ExplainError(
            f"cannot resolve {query!r} to a registry setting "
            f"(see --list-tools for paths)"
        )

    needed = [spec.path]
    for rule in EXPLAIN_RULES:
        if rule["path"] != spec.path:
            continue
        for p in _paths_in(str(rule["when"])):
            if p not in needed:
                needed.append(p)
    state = _read_state(target, [tool_by_path(p) for p in needed if tool_by_path(p)])

    for rule in EXPLAIN_RULES:
        if rule["path"] != spec.path:
            continue
        if _eval_when(rule, state):
            cites = tuple(str(c) for c in rule["cites"])  # type: ignore[arg-type]
            return {
                "ok": True,
                "answer": _render(str(rule["answer"]), state, cites),
                "cites": cites,
                "rule": True,
                "spec": spec,
            }

    # Value readback fallback, in the issue's own style.
    cite = spec.citations[0][0] if spec.citations else ""
    if spec.kind == "enum":
        validation = "one of " + "|".join(str(v) for v in (spec.enum or ()))
    elif spec.kind == "bool":
        validation = "on/off"
    elif spec.kind == "string":
        validation = "string"
    else:
        validation = f"range {spec.minimum}-{spec.maximum}"
    value = state.get(spec.path, spec.default)
    answer = (
        f"The {spec.path} is currently set to {_fmt(value)} "
        f"({validation}, default {_fmt(spec.default)}"
        + (f"; {cite}" if cite else "") + ")."
    )
    return {
        "ok": True,
        "answer": answer,
        "cites": tuple(c[0] for c in spec.citations[:2]),
        "rule": False,
        "spec": spec,
    }
